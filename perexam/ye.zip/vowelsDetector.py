"""
09/05/2024
Ayman Dghoughi Nouri
ASIXcB
M03 UF3 pp1
Descripció: coming soon...
"""

#def get_vowels_from_file():
